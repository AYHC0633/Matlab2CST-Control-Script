% Copyright (C) 2018  Symeon Symeonidis, Stefanos Tsantilas, Stelios Mitilineos
% simos421@gmail.com, steftsantilas@gmail.com, smitil@gmail.com
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

function JobID = CstAdd(mws,component1,component2,HistorySelect,JobID)

if HistorySelect == 0;

    Solid = invoke(mws,'Solid');
    invoke(Solid,'Add',component1,component2);

%%% -----------------------add on module-------adding History list in CST-------------------%%%

else;
        mws.invoke('AddToHistory', ['Boolean_add_shapes ' char(component1) ',' char(component2) '_' num2str(JobID)],[...
            sprintf(' Solid.Add "%s", "%s"',component1,component2)]);
end;
     
   JobID = JobID + 1;
   return; 

end