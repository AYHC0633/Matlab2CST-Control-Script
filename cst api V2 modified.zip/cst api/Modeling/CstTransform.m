function JobID = CstTransform(mws,component,Vector,MultipleObject,Repetitions,HistorySelect,JobID)
        
if HistorySelect == 0
        transform = invoke(mws,'Transform');
        invoke(transform,'Name',component(1));

          if length(component) >1 
            for i= 2:length(component)
            invoke(transform,'AddName',component(i)); 
            end
          end

        invoke(transform,'Vector',char(num2str(Vector(1))), char(num2str(Vector(2))), char(num2str(Vector(3))));
        invoke(transform,'MultipleObjects',MultipleObject); %true or false , invoke(transform,'MultipleObjects',"True");
        invoke(transform,'Repetitions',num2str(Repetitions));
        invoke(transform,'Transform',"Shape", "Translate"); 

else
    %%% -----------------add-on historylist addition----------%%%


          if length(component) >1 
            for i= 2:length(component)
            Addname{i-1}= sprintf('  .AddName "%s" ',component(i)); 
            end

              mws.invoke('AddToHistory', ['Transform_' char(component(1)) '_' num2str(JobID)],[
            sprintf('With Transform\n')...
            sprintf('  .Reset\n')...
            sprintf('  .Name "%s" \n',component(1))...
            sprintf('  %s\n',string(Addname))...
            sprintf(' .vector "%s","%s","%s" \n',num2str(Vector(1)),num2str(Vector(2)),num2str(Vector(3)))...
            sprintf(' .MultipleObjects "%s" \n',MultipleObject)...
            sprintf(' .Repetitions "%d" \n',Repetitions)...
            sprintf(' .MultipleSelection "False" \n')...
             sprintf(' .Transform "Shape", "Translate" \n')...
            sprintf('End With')]);

          else
               mws.invoke('AddToHistory', ['Transform_' char(component(1)) '_' num2str(JobID)],[
            sprintf('With Transform\n')...
            sprintf('  .Reset\n')...
            sprintf('  .Name "%s" \n',component(1))...
            sprintf(' .vector "%s","%s","%s" \n',num2str(Vector(1)),num2str(Vector(2)),num2str(Vector(3)))...
              sprintf(' .UsePickedPoints "False" \n')...
            sprintf(' .InvertPickedPoints "False" \n')...
            sprintf(' .MultipleObjects "%s" \n',MultipleObject)...
            sprintf(' .GroupObjects "False" \n')...
            sprintf(' .Repetitions "%d" \n',Repetitions)...
            sprintf(' .MultipleSelection "False" \n')...
             sprintf(' .Transform "Shape", "Translate" \n')...
            sprintf('End With')]);

          end

           

end

JobID = JobID + 1;

end
%CstTransform(mws,component,[2 0 0],"false",1)


%  %-------------------------## transformation----------------%
%      %%%-----structure
%     %## --- transform by position
%         transform = invoke(mws,'Transform')
%         invoke(transform,'Name',component); 
%         invoke(transform,'Vector',"-WL", "0", "0");
%           invoke(transform,'MultipleObjects',"True");
%           invoke(transform,'Repetitions',"4");
%         invoke(transform,'Transform',"Shape", "Translate"); 