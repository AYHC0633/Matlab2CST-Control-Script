

function JobID = CstDefine2DCurve(mws, Name, curve, Upoint, Vpoint,HistorySelect,JobID)

% Create a brick
% Name = Name of the brick (String) 'Solid1'
% component = component list (String) 'component1'
% material = 'PEC' or 'Vaccumm' otherwise you have to call the function of
% the material you want to use before this one
% Xrange, Yrange, Zrange = starting and finishing range e.g. [0 10] (integers) 

if HistorySelect == 0;
%     brick = invoke(mws,'Brick');
%     invoke(brick,'Reset');
%     invoke(brick,'Name',Name);
%     invoke(brick,'component',component);
%     invoke(brick,'Material',material);
% 
% 
%     invoke(brick,'Xrange',int2str(Xrange(1)),int2str(Xrange(2)));
%     invoke(brick,'Yrange',int2str(Yrange(1)),int2str(Yrange(2)));
%     invoke(brick,'Zrange',int2str(Zrange(1)),int2str(Zrange(2)));
% 
% 
% invoke(brick,'Create');
% 
% release(brick);

%%% -----------------------add on module-------adding History list in CST-------------------%%%

else;

     for i= 2:length(Upoint)
        ExcPoMo{i-1}= sprintf('  .LineTo "%s" , "%s" ',num2str(Upoint(i)),num2str(Vpoint(i)));
     end

        mws.invoke('AddToHistory', ['Define_curve_' num2str(JobID)],[...
            sprintf('With Polygon \n') ...
            sprintf('  .Reset\n') ...
            sprintf('  .Name "%s"\n',Name) ...
            sprintf('  .Curve "%s"\n',curve) ... 
            sprintf('  .Point  "%s","%s"\n',num2str(Upoint(1)),num2str(Vpoint(1))) ...
            sprintf('   %s\n', string(ExcPoMo))...
            sprintf(' .Create\n') ...
            sprintf('End With')]);
end;
     
   JobID = JobID + 1;

   return; 
     
end