function JobID = CstPortTransform(mws,port,Vector,MultipleObject,Repetitions,HistorySelect,JobID)
        
if HistorySelect == 0;

        transform = invoke(mws,'Transform');
        invoke(transform,'Name',port(1)); 
       
       if length(port) >1; 
            for i= 2:length(port);
            invoke(transform,'AddName',port(i)); 
            end;
       end;

        invoke(transform,'Vector',num2str(Vector(1)),num2str(Vector(2)), num2str(Vector(3)));
          invoke(transform,'MultipleObjects',MultipleObject);
          invoke(transform,'Repetitions',num2str(Repetitions));
        invoke(transform,'Transform',"port", "Translate"); 
else;
        
    
    if length(port) >1;
       Addname{1} = sprintf('  .Name "%s" ',port(1));
        for i= 2:length(port);
        Addname{i}= sprintf('  .AddName "%s" ',port(i));
        end;
    else;
        Addname{1} = sprintf('  .Name "%s" ',port(1));
    end;

    mws.invoke('AddToHistory', ['PortTransform_' num2str(JobID)],[
            sprintf('With Transform\n')...
            sprintf('  .Reset\n')...
            sprintf('  %s\n',string(Addname))...
            sprintf(' .vector "%s","%s","%s" \n',num2str(Vector(1)),num2str(Vector(2)),num2str(Vector(3)))...
            sprintf(' .UsePickedPoints "False" \n')...
            sprintf(' .InvertPickedPoints "False" \n')...
            sprintf(' .MultipleObjects "%s" \n',MultipleObject)...
            sprintf(' .GroupObjects "False" \n')...
            sprintf(' .Repetitions "%d" \n',Repetitions)...
            sprintf(' .MultipleSelection "False" \n')...
             sprintf(' .Transform "port", "Translate" \n')...
            sprintf('End With')]);





JobID = JobID + 1;

end

%CstPortTransform(mws,port,[2 0 0],"false",1)