%% add-on module by AYHC

function JobID = Rename(mws,OriginalName,NewName,HistorySelect,JobID)

    if HistorySelect == 0
        Solid = invoke(mws,'Solid');
        invoke(Solid,'Rename',OriginalName,NewName);
    else 
        mws.invoke('AddToHistory', ['Rename_' char(NewName) '_' num2str(JobID)],[
            sprintf('Solid.Rename "%s", "%s"', OriginalName,NewName) ...
            ]);
    end

    JobID = JobID + 1;
end