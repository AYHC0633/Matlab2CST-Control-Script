% Copyright (C) 2018  Symeon Symeonidis, Stefanos Tsantilas, Stelios Mitilineos
% simos421@gmail.com, steftsantilas@gmail.com, smitil@gmail.com
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

function JobID = CstCylinderBending(mws,component1,angle,HistorySelect,JobID)
    if HistorySelect == 0;
        Bending = invoke(mws,'Bending ');
        invoke(Bending,'Reset');
        invoke(Bending,'Shape',component1);
        invoke(Bending,'Centralized',"False");
        invoke(Bending,'Angle',angle);
        invoke(Bending,'Radius',0);
        invoke(Bending,'FlexBend');

    else;
        mws.invoke('AddToHistory', ['Bending_' num2str(JobID)],[...
        sprintf('With Bending \n') ...
        sprintf('   .Reset \n') ...
        sprintf('   .Shape "%s" \n',component1) ...
        sprintf('   .Centralized "False" \n') ...
        sprintf('   .Angle "%s" \n',num2str(angle)) ...
        sprintf('   .radius "%s" \n',num2str(0)) ...
               sprintf('   .FlexBend \n') ...
        sprintf('End With \n') ...
            ]);

    end;

    JobID = JobID + 1;
   return;
end
