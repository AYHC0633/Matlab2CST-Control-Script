function CstQuitProject(mws)

mws.invoke('quit');
end